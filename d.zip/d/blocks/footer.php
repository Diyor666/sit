<footer>
    <div id="social">
        <a href="http://vk.com" title="Группа Вк" target="_blank">
            <img src="./img/vk.png" alt="Вк">
        </a>
        <a href="http://instagram.com" title="Группа Instagram" target="_blank">
            <img src="./img/instagram.png" alt="Instagram" title="Instagram">
        </a>
        <a href="http://twitter.com" title="Группа X" target="_blank">
            <img src="./img/twitter.png" alt="X" title="X">
        </a>
    </div>
    <div id="rights">  
        Все права защищены &copy; <?=date ('Y')?>
    </div>
</footer>