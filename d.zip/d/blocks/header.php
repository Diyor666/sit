<header>
    <div id="logo">
        <a href="/" title=" Перейти на главную">
            <span>К</span>омпас
        </a>
    </div>
    <div id="menuHead">
        <a href="about.php">
            <div style="margin-right: 5%;">О нас</div>
        </a>
        <a href="feedback.php">
            <div>Обратная связь</div>
        </a>
    </div>
    <div id="regAuth">
        <a href="reg.php">Регистрация</a> | <a href="auth.php">Авторизация</a>
    </div>
</header>