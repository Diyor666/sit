<div id="rightCol">
    <div class="banner">
        <img src="./img/banner_1.png" alt="Баннер 1" title="Баннер 1">
    </div>
    <div class="banner">
        <img src="./img/banner_2.png" alt="Баннер 2" title="Баннер 2">
    </div>
</div>